<?php
$title = 'My Blog:: About';
$post = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolor modi, molestias mollitia nostrum obcaecati,
    officiis perferendis, porro quasi quo veritatis vero vitae. Adipisci eligendi enim exercitationem maiores pariatur
    quam!
</p>
<p>Assumenda consectetur distinctio explicabo, harum nam nihil numquam perferendis placeat praesentium
    quasi sequi soluta tempora temporibus unde voluptatem? Alias, eos fugit harum illum natus nesciunt nihil quae
    tempora totam veniam.
</p>
<p>Ad animi architecto aspernatur assumenda commodi cumque earum ex expedita illo iste
    laudantium magni nihil officia officiis omnis quas quis reiciendis sequi, velit voluptatem. Atque autem consectetur
    exercitationem iste voluptate.
</p>';


$resent_posts = [
    1 => [
        'title' => 'An item',
        'slug' => lcfirst(str_replace(' ','-','An item')),
    ],
    2 => [
        'title' => 'A second item',
        'slug' => lcfirst(str_replace(' ','-','A second item')),
    ],
    3 => [
        'title' => 'A third item',
        'slug' => lcfirst(str_replace(' ','-','A third item')),
    ],
    4 => [
        'title' => 'A fourth item',
        'slug' => lcfirst(str_replace(' ','-','A fourth item')),
    ],
    5 => [
        'title' => 'And a fifth one',
        'slug' => lcfirst(str_replace(' ','-','And a fifth one')),
    ],
];
require VIEWS . "/about.tpl.php";
?>
