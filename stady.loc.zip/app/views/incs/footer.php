<footer class="footer">
    <div class="p-3 bg-dark text-white text-center">
        <p>
            &copy; Copyright <?= date("Y")?>
        </p>
    </div>
</footer>
</div>

<script src = "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>