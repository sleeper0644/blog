<div class="col-md-4">
    <h3>Resent posts</h3>
    <ul class="list-group">
        <?php foreach ($resent_posts as $resent_post):?>
            <li class="list-group-item"><a href="post?id=<?= $resent_post['id']?>"><?= $resent_post['title']?></a></li>
        <?php endforeach;?>
    </ul>
</div>
