<?php

require dirname(__DIR__) . '/config/config.php';
require CORE . '/func.php';

require CORE . '/classes/Db.php';

$db_config = require CONFIG . '/db.php';
$db = new Db($db_config);
/* $db2 = new Db($db_config);
dump($db);
dd($db2); */

require CORE . '/router.php';