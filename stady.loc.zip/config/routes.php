<?php
$routes = [
    ''=>'index.php',
    'about'=>'about.php',
    'post'=>'post.php',
];